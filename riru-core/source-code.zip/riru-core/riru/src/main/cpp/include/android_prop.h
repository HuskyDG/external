#pragma once

namespace android_prop {

    const char* GetRelease();

    int GetApiLevel();

    int GetPreviewApiLevel();

    bool CheckZTE();
}
