#ifndef DL_H
#define DL_H

void *DlopenExt(const char *path, int flags);

#endif //DL_H
