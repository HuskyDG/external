//
// Created by canyie on 2021/1/1.
//

#ifndef RIRU_MOMOHIDER_MAGISKHIDE_H
#define RIRU_MOMOHIDER_MAGISKHIDE_H

void hide_unmount(const char* magisk_tmp);

#endif //RIRU_MOMOHIDER_MAGISKHIDE_H
