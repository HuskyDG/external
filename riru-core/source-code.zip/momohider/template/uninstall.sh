# Before v22
rm -rf /data/misc/riru/modules/momohider

# After v22
rm -rf /data/adb/riru/modules/momohider

rm -rf /data/adb/momohider/