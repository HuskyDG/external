# Riru - Enhanced mode for Magisk Hide

Enable Enhanced mode for Magisk Hide. Allow Magisk Hide to handle isolated processes.

Request the latest Magisk version (version code >= 22006)
